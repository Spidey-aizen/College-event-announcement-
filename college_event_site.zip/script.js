function showAlert() {
    alert('More details will be updated soon!');
}
